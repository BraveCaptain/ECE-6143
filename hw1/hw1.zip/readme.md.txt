#problem 1
run p1/p1.m

#problem 2
run p2/p2.m

#problem 4
run p4/p4.m